import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../controllers/completejob_controller.dart';

class CompletejobView extends GetView<CompletejobController> {
  const CompletejobView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CompletejobView'),
        centerTitle: true,
      ),
      body: const Center(
        child: Text(
          'CompletejobView is working',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
